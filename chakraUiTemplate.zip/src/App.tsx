import { ChakraProvider, theme } from "@chakra-ui/react";
import Header from "./Layout/Header";
import { createBrowserRouter, Outlet } from "react-router-dom";
import { Authentications } from "./Features/Authentications/Authentications";
import { Scanner } from "./Features/Scanners/Scanners";
import { RegisterApi } from "./Features/RegisterApi/RegisterApi";
import Login from "./Features/Auth/Login/Login";
import { Dashboard } from "./Features/Dashboard/Dashboard";
import { ApiView } from "./Features/RegisterApi/ApiView";
import { Provider } from "jotai";
import { asStore } from "./Utilities/Store/Store";
import ProtectedRoute from "./Utilities/Auth/ProtectedRoute";
import TenantInfo from "./Features/TenantInfo/TenantInfo";

export const App = () => (
  <ChakraProvider theme={theme}>
    <Provider store={asStore}>
      <Header />
      <Outlet />
    </Provider>
  </ChakraProvider>
);
{
  /* <ProtectedRoute >
        <DashboardPage /> 
      </ProtectedRoute> */
}
export const appRouter = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    // errorElement: <Error />,
    children: [
      {
        path: "/",
        element: (
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        ),
      },
      {
        path: "/register",
        element: (
          <ProtectedRoute>
            <RegisterApi />{" "}
          </ProtectedRoute>
        ),
      },
      {
        path: "/register/:id",
        element: (
          <ProtectedRoute>
            <ApiView />{" "}
          </ProtectedRoute>
        ),
      },
      {
        path: "/authentications",
        element: (
          <ProtectedRoute>
            <Authentications />
          </ProtectedRoute>
        ),
      },
      {
        path: "/scanner",
        element: (
          <ProtectedRoute>
            <Scanner />
          </ProtectedRoute>
        ),
      },
      {
        path: "/tenantInfo",
        element: (
          <ProtectedRoute>
            <TenantInfo />
          </ProtectedRoute>
        ),
      },
      {
        path: "/login",
        element: <Login />,
      },
    ],
  },
]);
