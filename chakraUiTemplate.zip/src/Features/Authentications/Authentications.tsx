import { Flex } from "@chakra-ui/react";
import { ASEditor } from "../../Ui/Organisms/ASEditor/ASEditor";

export const Authentications = () => (
  <Flex mt={10} w="80vw" h="80vh">
    <ASEditor></ASEditor>
  </Flex>
);
