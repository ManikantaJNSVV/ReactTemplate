import { Box, SimpleGrid } from "@chakra-ui/react";
import { ASStatsCard } from "../../Ui/Molecules/ASStatCard";
import { FiClock } from "react-icons/fi";
import { FiPlus } from "react-icons/fi";
import { FiUser } from "react-icons/fi";
import { getIsAuthenticated } from "../../Utilities/Store/Store";

export const Dashboard = () => {
  const isAuth = getIsAuthenticated();
  // console.log(process.env.REACT_APP_BASE_URL);
  console.log(isAuth);
  return (
    <Box maxW="7xl" mx={"auto"} pt={5} px={{ base: 2, sm: 12, md: 17 }}>
      <SimpleGrid columns={{ base: 1, md: 3 }} spacing={{ base: 5, lg: 8 }}>
        <ASStatsCard
          title={"Register API"}
          stat={"Register your Apis"}
          icon={<FiPlus size={"3em"} />}
        />
        <ASStatsCard
          title={"Insights and Reports"}
          stat={"Get to know about your api insights"}
          icon={<FiClock size={"3em"} />}
        />
        <ASStatsCard
          title={"Adminstration"}
          stat={"Manage users,Admins etc"}
          icon={<FiUser size={"3em"} />}
        />
      </SimpleGrid>
      {/* <Text fontSize={"3xl"} color={"black"}>
        {isAuth + ""}
      </Text> */}
    </Box>
  );
};
