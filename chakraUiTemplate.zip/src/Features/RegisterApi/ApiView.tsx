import { Box, Text } from '@chakra-ui/react';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';

export const ApiView = () =>{
    const { id } = useParams();
    useEffect(()=>{
     console.log('**** Hello API view ****');
     console.log(id);
    },[])
    
    return(<Box><Text>{id}</Text></Box>);
}