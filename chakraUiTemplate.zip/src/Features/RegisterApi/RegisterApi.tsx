// RegisterApi.tsx
import { Flex, Text } from "@chakra-ui/react";
import * as Yup from "yup";
import AsForm, { FieldType } from "../../Ui/Organisms/AsForm/AsForm";

export const RegisterApi = () => {
  const formConfig = {
    fields: {
      firstName: {
        type: "text" as FieldType,
        label: "First Name",
        required: true,
        validation: Yup.string().required("First Name is required"),
      },
      lastName: {
        type: "text" as FieldType,
        label: "Last Name",
        required: true,
        validation: Yup.string().required("Last Name is required"),
        helperText: "Enter your last name",
      },
      address: {
        type: "text" as FieldType,
        label: "Address",
        required: true,
        validation: Yup.string().required("Address is required"),
        helperText: "Enter your address",
      },
    },
    initialValues: {
      firstName: "",
      lastName: "",
      address: "",
    },
  };

  const handleChange = (values: any) => {
    console.log("Form values:", values);
  };

  const handleFormValidityChange = (isValid: any) => {
    console.log("Form validity:", isValid);
  };

  return (
    <Flex color="white" mt={10} w="80vw" h="80vh">
      <Text>Register api</Text>
      <AsForm
        fields={formConfig.fields}
        initialValues={formConfig.initialValues}
        onChange={handleChange}
        onFormValidityChange={handleFormValidityChange}
      />
    </Flex>
  );
};
