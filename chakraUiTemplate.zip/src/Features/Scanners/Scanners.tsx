import { Flex } from "@chakra-ui/react";
import FormBasic from "../../Ui/Organisms/AsForm/FormBasic";
import MainComponent from "../../Ui/TestFolder/MainComponent";

export const Scanner = () => (
  <Flex mt={10} w="80vw" h="80vh">
    <FormBasic></FormBasic>
    <MainComponent></MainComponent>
  </Flex>
);
