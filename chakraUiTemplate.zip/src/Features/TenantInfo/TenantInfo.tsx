import { Box } from "@chakra-ui/react";
import AsInfoCard from "../../Ui/Molecules/AsInfoCard";
import AsBanner from "../../Ui/Atoms/AsBanner";

const TenantInfo = () => {
  const cardData = {
    header: "Tenant Info",
    info: "Overview of Tenant Information",
    data: [
      { label: "Company Name", value: "template" },
      { label: "Reporting Emails", value: "admin@template.ui" },
      { label: "Enable 2FA", value: "no" },
      { label: "Licenses", value: "500 ( 496 in-use and 4 available )" },
      { label: "Industry", value: "Health Care" },
    ],
  };

  return (
    <>
      <Box mt={2}>
        <AsBanner
          mainInfo=" Start your onboarding!"
          subInfo="We have set up your tenant. This will be your consolidated space in our cloud
"
        ></AsBanner>
        <Box m={2}>
          <AsInfoCard {...cardData}></AsInfoCard>
        </Box>
      </Box>
    </>
  );
};

export default TenantInfo;
