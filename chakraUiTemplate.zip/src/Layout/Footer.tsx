import { Text } from "@chakra-ui/react";

export const Footer = () => <Text>Hello</Text>;
