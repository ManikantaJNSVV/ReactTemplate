import { Box, Flex, Text } from '@chakra-ui/react';

interface AsBannerProps {
  mainInfo: string;
  subInfo: string;
}

const AsBanner = ({mainInfo,subInfo}:AsBannerProps) => (

  
  <Box as="section" p={{ base: '2', md: '4' }} borderWidth="1px" m={2} borderColor={'gray.200'} bg="bg.surface" 
  bgGradient='linear(to-r, #fdfbfb, #ebedee)'
  >
  
    <Flex direction='column' justify="space-between" align="left">
      <Text fontWeight="medium" mb={{ base: '2', md: '0' }}>
        {mainInfo}
      </Text>
      <Text color="fg.muted" textAlign={{ base: 'left', md: 'left' }}>
        {subInfo}
      </Text>
    </Flex>
  </Box>
);

export default AsBanner;
