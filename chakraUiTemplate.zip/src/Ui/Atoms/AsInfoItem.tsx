import { SystemStyleObject, Text } from "@chakra-ui/react";

interface AsInfoItemProps {
  label: string;
  value: string;
}

const AsInfoItem = ({ label, value }: AsInfoItemProps) => {
  return (
    <>
      <Text sx={infoLabel}>{label} :</Text> 
      <Text sx={infoValue}> {value}</Text>
    </>
  );
};

const infoLabel: SystemStyleObject = {
  fontWeight: "bold",
  fontSize: 12,
  mr: 2,
};

const infoValue: SystemStyleObject = {
  fontSize: 12,
};

export default AsInfoItem;
