import {
  Card,
  CardHeader,
  CardBody,
  Text,
  Flex,
  SimpleGrid,
  IconButton,
  Divider,
} from "@chakra-ui/react";
import AsInfoItem from "../Atoms/AsInfoItem";
import { FiEdit2 } from "react-icons/fi";

interface AsInfoCardProps {
  header: string;
  info: string;
  data: { label: string; value: string }[];
}

const AsInfoCard = ({ header, info, data }: AsInfoCardProps) => {
  return (
    <Card
      variant={"outline"}
      borderWidth="1px"
      borderRadius="lg"
      bgColor={"gray.50"}
      borderColor={"gray.200"}
      _hover={{ shadow: "xs" }}
    >
      <CardHeader>
        <Flex justify="space-between">
          <Flex justify="space-between" flexDirection={"column"}>
            <Text fontSize="md" fontWeight="bold">
              {header}
            </Text>
            <Text fontSize="xs">{info}</Text>
          </Flex>
          <IconButton
            icon={<FiEdit2 />}
            variant="tertiary"
            aria-label="Close banner"
          />
        </Flex>
      </CardHeader>
      <Divider />
      <CardBody>
        <SimpleGrid columns={2} spacing={2}>
          {data.map((info: any, index: any) => (
            <Flex key={index}>
              <AsInfoItem label={info.label} value={info.value}></AsInfoItem>
            </Flex>
          ))}
        </SimpleGrid>
      </CardBody>
    </Card>
  );
};

export default AsInfoCard;
