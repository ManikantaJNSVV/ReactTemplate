import AceEditor from "react-ace";

import "ace-builds/src-noconflict/mode-java";
import "ace-builds/src-noconflict/theme-github";
import "ace-builds/src-noconflict/ext-language_tools";

export const ASEditor = () => {

   return (
    <AceEditor
    setOptions={{ useWorker: false }}
    mode="javascript"
    theme="github"
    name="editor"
    value='{
        "amount" : "{{@Var.amount}}",
        "availableBalance" : "{{@Var.availableBalance}}",
        "createdBy" : "{{@Var.createdBy}}",
        "createdDate" : "{{@Var.createdDate}}",
        "description" : "{{@Var.description}}",
        "id" : "{{@Var.id}}",
        "inactive" : false,
        "modifiedBy" : "{{@Var.modifiedBy}}",
        "modifiedDate" : "{{@Var.modifiedDate}}",
        "status" : "{{@Var.status}}",
        "type" : "{{@Var.type}}",
        "user" : {
          "createdBy" : "{{@Var.createdBy}}",
          "createdDate" : "{{@Var.createdDate}}",
          "id" : "{{@Var.id}}",
          "inactive" : false,
          "modifiedBy" : "{{@Var.modifiedBy}}",
          "modifiedDate" : "{{@Var.modifiedDate}}",
          "name" : "{{@Var.name}}",
          "version" : "{{@Var.version}}"
        }'
    fontSize={14}
    editorProps={{$blockScrolling: true}}
  />
   )
   }