import { useMemo, useEffect } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-quartz.css";
import { ColDef, GridReadyEvent } from "ag-grid-community";

interface AsTableProps {
  rowData: any[];
  columnDefs: ColDef[];
}

const AsTable = ({ rowData, columnDefs }: AsTableProps) => {
  const containerStyle = useMemo(() => ({ width: "100%", height: "20vh" }), []);
  const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);

  useEffect(() => {
    // If you want to perform any actions when rowData or columnDefs change, you can do it here.
  }, [rowData, columnDefs]);

  const onGridReady = (params: GridReadyEvent) => {
    params.api.addGlobalListener((type: string, e: any) => {
      if (type === "rowClicked" || type === "rowSelected") {
        console.log(type, "from global event handler");
        console.log(e);
      }
    });
  };

  return (
    <div style={{ ...containerStyle, overflow: "hidden" }}>
      <div
        className="ag-theme-quartz"
        style={{ ...gridStyle, width: "calc(100% - 8px)" }}
      >
        <AgGridReact<any>
          rowData={rowData}
          columnDefs={columnDefs}
          onGridReady={onGridReady}
        />
      </div>
    </div>
  );
};

export default AsTable;
