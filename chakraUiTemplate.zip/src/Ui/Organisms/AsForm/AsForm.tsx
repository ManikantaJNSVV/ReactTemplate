import React, { useEffect } from "react";
import {
  FormControl,
  FormLabel,
  Input,
  FormErrorMessage,
  FormHelperText,
  Select,
  Textarea,
} from "@chakra-ui/react";
import { useFormik } from "formik";
import * as Yup from "yup";

export type FieldType = "text" | "textarea" | "select";

interface FieldConfig {
  type: FieldType;
  label: string;
  options?: string[];
  required?: boolean;
  validation?: Yup.StringSchema<string | undefined, object>;
  visible?: boolean;
  helperText?: string;
}

interface AsFormProps {
  fields: Record<string, Omit<FieldConfig, "name"> & { label: string }>;
  initialValues: Record<string, any>;
  onChange?: (values: Record<string, any>) => void;
  onFormValidityChange?: (isValid: boolean) => void;
}

const inputTypes: any = {
  text: Input,
  textarea: Textarea,
  select: Select,
};

const createValidationSchema = (formConfig: any) => {
  const schemaConfig: { [key: string]: Yup.AnySchema } = {};
  Object.entries(formConfig).forEach(([fieldName, config]: any) => {
    schemaConfig[fieldName] = config.validation || Yup.mixed();
  });

  return Yup.object().shape(schemaConfig);
};

const AsForm: React.FC<AsFormProps> = ({
  fields,
  initialValues,
  onChange,
  onFormValidityChange,
}) => {
  const formik = useFormik({
    initialValues,
    validationSchema: createValidationSchema(fields),
    onSubmit: () => {}, // No need for onSubmit in this case
  });

  useEffect(() => {
    if (onChange) {
      onChange(formik.values);
    }
  }, [formik.values, onChange]);

  useEffect(() => {
    if (onFormValidityChange) {
      onFormValidityChange(formik.isValid);
    }
  }, [formik.isValid, onFormValidityChange]);

  const handleInputChange = (name: string, value: any) => {
    formik.setFieldValue(name, value);
  };

  const generateFormFields = () => {
    return Object.entries(fields).map(([name, field]: any) => {
      const { type, label, options, required, helperText } = field;
      const InputComponent = inputTypes[type] || Input;

      return (
        <FormControl
          key={name}
          mb={4}
          color={"black"}
          isInvalid={!!(formik.touched[name] && formik.errors[name])}
        >
          <FormLabel color={"black"}>
            {label} {required && <span style={{ color: "red" }}>*</span>}
          </FormLabel>
          <InputComponent
            type={type === "select" ? undefined : type}
            name={name}
            value={formik.values[name]}
            onChange={(e: any) => handleInputChange(name, e.target.value)}
            onBlur={formik.handleBlur}
            placeholder={label}
            {...(type === "select"
              ? {
                  children: options?.map((opt: any) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  )),
                }
              : {})}
          />
          <FormHelperText>{helperText}</FormHelperText>
        </FormControl>
      );
    });
  };

  return <form>{generateFormFields()}</form>;
};

export default AsForm;
