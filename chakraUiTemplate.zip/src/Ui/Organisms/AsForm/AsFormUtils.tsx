import { Input, Textarea, Checkbox, Switch, Select } from "@chakra-ui/react";
import { Field, useFormik } from "formik";

interface GetInputElementProps {
  type: string | any;
  fieldName: string | any;
  formik: ReturnType<typeof useFormik>;
  options?: any[] | any;
  label?: string | any;
}

export const getInputElement = ({
  type,
  fieldName,
  formik,
  options,
  label,
}: GetInputElementProps): React.ReactNode => {
  const handleInputChange = (value: any) => {
    formik.setFieldValue(fieldName, value);
    formik.setFieldTouched(fieldName, true, false);
  };

  switch (type) {
    case "text":
      return (
        <Field
          as={Input}
          type="input"
          name={fieldName}
          value={formik.values[fieldName] as any}
          onChange={(e: any) => handleInputChange(e.target.value)}
        />
      );
    default:
      return null;
  }
};
