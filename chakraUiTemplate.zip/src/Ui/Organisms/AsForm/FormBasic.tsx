import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import {
  FormControl,
  FormLabel,
  Input,
  Button,
  FormErrorMessage,
} from "@chakra-ui/react";

const FormBasic = () => {
  const DisplayingErrorMessagesSchema = Yup.object().shape({
    username: Yup.string()
      .min(2, "Username is too short!")
      .max(50, "Username is too long!")
      .required("Username is required"),
    email: Yup.string().email("Invalid email").required("Email is required"),
  });

  return (
    <Formik
      initialValues={{
        username: "",
        email: "",
      }}
      validationSchema={DisplayingErrorMessagesSchema}
      onSubmit={(values) => {
        console.log(values);
      }}
    >
      {({ errors, touched, isValid }) => (
        <Form>
          <FormControl
            id="username"
            isInvalid={!!(touched.username && errors.username)}
          >
            <FormLabel>Username</FormLabel>
            <Field as={Input} type="input" name="username" />
            <FormErrorMessage>{errors.username}</FormErrorMessage>
          </FormControl>

          <FormControl id="email" isInvalid={!!(touched.email && errors.email)}>
            <FormLabel>Email address</FormLabel>
            <Field as={Input} type="input" name="email" />
            <FormErrorMessage>{errors.email}</FormErrorMessage>
          </FormControl>

          <Button
            type="submit"
            bg={"blue.400"}
            color={"white"}
            _hover={{
              bg: "blue.500",
            }}
            disabled={!isValid}
          >
            Submit
          </Button>
        </Form>
      )}
    </Formik>
  );
};

export default FormBasic;
