import { Box, Button, VStack } from '@chakra-ui/react';
import {ArrowRightIcon, ArrowLeftIcon } from '@chakra-ui/icons';

const List = ({ title, items, onArrowClick, onShuffleClick }:any) => {
  return (
    <Box>
      <VStack align="flex-start" spacing={4}>
        <Box>{title}</Box>
        {items.map((item:any) => (
          <Box key={item}>{item}</Box>
        ))}
      </VStack>
      <Box>
        <Button onClick={() => onArrowClick('right')}>
          <ArrowRightIcon />
        </Button>
        <Button onClick={() => onArrowClick('left')}>
          <ArrowLeftIcon />
        </Button>
        <Button onClick={onShuffleClick}>Shuffle</Button>
      </Box>
    </Box>
  );
};

export default List;
