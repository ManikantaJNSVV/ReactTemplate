import { useState } from "react";
import { Box, Button, Flex, List, ListItem, Text } from "@chakra-ui/react";

const MainComponent = () => {
  const [recommendedList, setRecommendedList] = useState([
    "HIPAA",
    "SOC",
    "CCPA",
    "GDPR",
  ]);
  const [selectedList, setSelectedList] = useState<string[]>([]);
  const [selectedItem, setSelectedItem] = useState<string | null>(null);

  const moveItem = (
    item: string,
    sourceList: string[],
    destinationList: string[]
  ) => {
    const updatedSourceList = sourceList.filter((i) => i !== item);
    const updatedDestinationList = [...destinationList, item];

    setRecommendedList(updatedSourceList);
    setSelectedList(updatedDestinationList);
    setSelectedItem(null); // Deselect the item after moving
  };

  const handleSelectItem = (item: string) => {
    // Toggle selection
    if (selectedItem === item) {
      setSelectedItem(null); // Deselect the item
    } else {
      setSelectedItem(item);
    }
  };

  return (
    <Flex align="center" justify="center" mt="4">
      <List>
        <Text mb="2" position="sticky" top="0" backgroundColor="white">
          Recommended List
        </Text>
        {recommendedList.map((item) => (
          <ListItem
            key={item}
            onClick={() => handleSelectItem(item)}
            style={{
              backgroundColor: selectedItem === item ? "lightblue" : "white",
            }}
          >
            {item}
          </ListItem>
        ))}
      </List>

      <Box mx="4">
        <Flex direction="column" align="center">
          <Button
            onClick={() => {
              if (selectedItem)
                moveItem(selectedItem, selectedList, recommendedList);
            }}
          >
            {"<"}
          </Button>
          <Button
            onClick={() => {
              if (selectedItem)
                moveItem(selectedItem, recommendedList, selectedList);
            }}
          >
            {">"}
          </Button>
        </Flex>
      </Box>

      <List>
        <Text mb="2" position="sticky" top="0" backgroundColor="white">
          Selected List
        </Text>
        {selectedList.map((item) => (
          <ListItem
            key={item}
            onClick={() => handleSelectItem(item)}
            style={{
              backgroundColor: selectedItem === item ? "lightblue" : "white",
            }}
          >
            {item}
          </ListItem>
        ))}
      </List>
    </Flex>
  );
};

export default MainComponent;
