import { getIsAuthenticated } from '../Store/Store';
import { useNavigate } from 'react-router-dom';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

const ProtectedRoute = ({ children }: ProtectedRouteProps): JSX.Element | null => {
  const isAuthenticated = getIsAuthenticated();
  const navigate = useNavigate();
  if (!isAuthenticated) {
    navigate('/login');
    return null;
  }
  return <>{children}</>;
};

export default ProtectedRoute;
