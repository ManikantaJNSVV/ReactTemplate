import axios from "axios";

const apiService = axios.create({
  baseURL: "http://localhost:4200/",
  headers: {
    "Content-Type": "application/json",
  },
});

// Request interceptor
apiService.interceptors.request.use(
  (config) => {
    const token = ""; // Replace with your actual token or fetch it from a secure source
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// // Response interceptor
// apiService.interceptors.response.use(
//   (response) => {
//     return response;
//   },
//   (error) => {
//     return Promise.reject(error);
//   }
// );

export const get = async (url: any, params?: any) => {
  try {
    const response = params
      ? await apiService.get(url, { params })
      : await apiService.get(url);
    return response.data;
  } catch (error) {
    // Handle error (e.g., show a notification, log, etc.)
    throw error;
  }
};

export const post = async (url: any, data: any) => {
  try {
    const response = await apiService.post(url, data);
    return response.data;
  } catch (error) {
    // Handle error
    throw error;
  }
};

export const put = async (url: any, data: any) => {
  try {
    const response = await apiService.put(url, data);
    return response.data;
  } catch (error) {
    // Handle error
    throw error;
  }
};

export const del = async (url: any) => {
  try {
    const response = await apiService.delete(url);
    return response.data;
  } catch (error) {
    // Handle error
    throw error;
  }
};
