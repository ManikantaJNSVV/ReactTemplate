import { createStore,atom } from "jotai"

export const asStore = createStore();
const isAuthenticated = atom(true);
asStore.set(isAuthenticated, true);

export const getIsAuthenticated = () => asStore.get(isAuthenticated);